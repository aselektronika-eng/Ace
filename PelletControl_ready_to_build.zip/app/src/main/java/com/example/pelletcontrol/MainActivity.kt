package com.example.pelletcontrol

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var ipInput: EditText
    private lateinit var connectionText: TextView
    private lateinit var waterTemp: TextView
    private lateinit var roomTemp: TextView
    private lateinit var stateText: TextView
    private lateinit var pelletText: TextView
    private lateinit var statusText: TextView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(22, 34, 48)
        window.navigationBarColor = Color.rgb(22, 34, 48)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        addText("PELLET CONTROL", 26f, Color.rgb(22, 34, 48), true)
        addText("ESP32 • Wi-Fi контролен панел", 14f, Color.DKGRAY)
        connectionText = addText("Статус: не е поврзан", 15f, Color.rgb(170, 70, 40), true)

        ipInput = EditText(this).apply {
            hint = "IP на ESP32 (пример 192.168.4.1)"
            setSingleLine(true)
            setText("192.168.4.1")
        }
        root.addView(ipInput, matchWidth())
        addButton("ПОВРЗИ СЕ / ОСВЕЖИ") { fetchStatus() }

        addText("МЕРЕЊА", 18f, Color.rgb(22, 34, 48), true)
        waterTemp = addText("Вода: -- °C", 23f, Color.BLACK, true)
        roomTemp = addText("Соба: -- °C", 23f, Color.BLACK, true)
        pelletText = addText("Потрошувачка: -- kg", 18f, Color.BLACK)
        stateText = addText("Режим: --", 18f, Color.BLACK, true)
        statusText = addText("Информација: подготвен за поврзување", 14f, Color.DKGRAY)

        addText("КОНТРОЛА", 18f, Color.rgb(22, 34, 48), true)
        addButton("БАРАЈ ГРЕЕЊЕ / START") { sendCommand("start") }
        addButton("STOP / ИСКЛУЧИ БАРАЊЕ ЗА ГРЕЕЊЕ") { sendCommand("stop") }
        addButton("ВКЛУЧИ / ИСКЛУЧИ ПУМПА") { sendCommand("pump_toggle") }

        addText("ЦЕЛНА ТЕМПЕРАТУРА НА ВОДАТА", 15f, Color.DKGRAY, true)
        val targetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val targetInput = EditText(this).apply {
            hint = "°C"
            setText("60")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
        }
        targetRow.addView(targetInput, LinearLayout.LayoutParams(0, -2, 1f))
        val targetButton = Button(this).apply { text = "ЗАДАЈ" }
        targetButton.setOnClickListener {
            val value = targetInput.text.toString().toIntOrNull()
            if (value == null || value !in 30..80) {
                statusText.text = "Внеси температура од 30 до 80 °C."
            } else sendCommand("set_target", value)
        }
        targetRow.addView(targetButton)
        root.addView(targetRow)

        addText("Напомена: интерфејсот испраќа команди до ESP32. Без соодветен firmware и независни хардверски заштити, не управувај со вистинска печка.", 13f, Color.rgb(150, 55, 35))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun addText(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 7, 0, 7)
        }
        root.addView(v, matchWidth())
        return v
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label }
        b.setOnClickListener { action() }
        root.addView(b, matchWidth())
    }

    private fun baseUrl(): String {
        var ip = ipInput.text.toString().trim()
        ip = ip.removePrefix("http://").removeSuffix("/")
        return "http://$ip"
    }

    private fun fetchStatus() {
        connectionText.text = "Статус: се поврзува..."
        executor.execute {
            try {
                val json = request("GET", "/api/status", null)
                runOnUiThread {
                    connectionText.text = "Статус: ESP32 поврзан"
                    connectionText.setTextColor(Color.rgb(25, 125, 75))
                    waterTemp.text = "Вода: ${json.optString("water_c", "--")} °C"
                    roomTemp.text = "Соба: ${json.optString("room_c", "--")} °C"
                    pelletText.text = "Потрошувачка: ${json.optString("pellets_kg", "--")} kg"
                    stateText.text = "Режим: ${json.optString("mode", "--")}"
                    statusText.text = "Информация: ${json.optString("message", "OK")}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    connectionText.text = "Статус: нема врска"
                    connectionText.setTextColor(Color.rgb(170, 70, 40))
                    statusText.text = "Провери IP и дали ESP32 има соодветен firmware."
                }
            }
        }
    }

    private fun sendCommand(command: String, value: Int? = null) {
        executor.execute {
            try {
                val body = JSONObject().put("command", command)
                if (value != null) body.put("value", value)
                val response = request("POST", "/api/command", body.toString())
                runOnUiThread {
                    statusText.text = "ESP32: ${response.optString("message", "Командата е испратена")}"
                    fetchStatus()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Командата не е испратена. Провери Wi-Fi и firmware."
                }
            }
        }
    }

    private fun request(method: String, path: String, body: String?): JSONObject {
        val conn = (URL(baseUrl() + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 2500
        conn.readTimeout = 2500
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return JSONObject(text)
    }
}
